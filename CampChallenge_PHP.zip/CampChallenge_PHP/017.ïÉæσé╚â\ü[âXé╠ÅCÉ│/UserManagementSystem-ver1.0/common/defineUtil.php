<?php
const ROOT_URL = 'http://localhost/matome/app';     //indexディレクトリへのURL
const TOP_URI = '/';                                //トップページ
const INSERT = 'insert.php';                   //登録ページ
const INSERT_CONFIRM = 'insert_confirm.php';   //登録確認ページ
const INSERT_RESULT = 'insert_result.php';     //登録完了ページ
const SEARCH = 'search.php';                   //検索ページ
